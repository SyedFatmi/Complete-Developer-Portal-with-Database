<?php
    require_once('../include/connection.php');
    require_once('../include/header.php');
    require_once('../include/sidebar.php');
    
    $where_clause = "WHERE 1=1"; 
    
    $action = isset($_GET['action']) ? $_GET['action'] : '';

    if ($action == 'fetch_developers') {
        $search = isset($_GET['search']) ? mysqli_real_escape_string($con, $_GET['search']) : '';
        $query = "SELECT id, developer_name FROM developer WHERE developer_name LIKE '%$search%' ORDER BY developer_name ASC";
        $result = mysqli_query($con, $query);
        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        echo json_encode($data);
        exit;
    }

    if ($action == 'fetch_projects') {
        $search = isset($_GET['search']) ? mysqli_real_escape_string($con, $_GET['search']) : '';
        $query = "SELECT id, project_name FROM project WHERE project_name LIKE '%$search%' ORDER BY project_name ASC";
        $result = mysqli_query($con, $query);
        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        echo json_encode($data);
        exit;
    }
?>

<?php
    $daily_query = "SELECT DATE(assign_date) as date, COUNT(*) as count FROM live_project p $where_clause GROUP BY DATE(assign_date)";
    $daily_result = mysqli_query($con, $daily_query);
    $daily_data = [];
    while ($row = mysqli_fetch_assoc($daily_result)) {
        $daily_data[] = $row;
    }

    $weekly_query = "SELECT YEAR(assign_date) as year, WEEK(assign_date) as week, COUNT(*) as count FROM live_project p $where_clause GROUP BY YEAR(assign_date), WEEK(assign_date)";
    $weekly_result = mysqli_query($con, $weekly_query);
    $weekly_data = [];
    while ($row = mysqli_fetch_assoc($weekly_result)) {
        $weekly_data[] = $row;
    }

    $monthly_query = "SELECT YEAR(assign_date) as year, MONTH(assign_date) as month, COUNT(*) as count FROM live_project p $where_clause GROUP BY YEAR(assign_date), MONTH(assign_date)";
    $monthly_result = mysqli_query($con, $monthly_query);
    $monthly_data = [];
    while ($row = mysqli_fetch_assoc($monthly_result)) {
        $monthly_data[] = $row;
    }

    $yearly_query = "SELECT YEAR(assign_date) as year, COUNT(*) as count FROM live_project p $where_clause GROUP BY YEAR(assign_date)";
    $yearly_result = mysqli_query($con, $yearly_query);
    $yearly_data = [];
    while ($row = mysqli_fetch_assoc($yearly_result)) {
        $yearly_data[] = $row;
    }
?>


<div class="col-md-10">
    <h2 class="mt-5 ml-5 chart-heading">Chart Detail Shows Daily, Weekly, Monthly and Yearly Projects.</h2>
    
    <div class="row my-charts">
        <div class="col-md-3">
            <h2 class="projects-added">Daily Projects Added</h2>
            <canvas id="dailyChartCanvas"></canvas>
        </div>
        <div class="col-md-3">
            <h2 class="projects-added">Weekly Projects Added</h2>
            <canvas id="weeklyChartCanvas"></canvas>
        </div>
        <div class="col-md-3">
            <h2 class="projects-added">Monthly Projects Added</h2>
            <canvas id="monthlyChartCanvas"></canvas>
        </div>
        <div class="col-md-3">
            <h2 class="projects-added">Yearly Projects Added</h2>
            <canvas id="yearlyChartCanvas"></canvas>
        </div>
    </div>

    <?php

    $filter_dev_name = isset($_GET['filter_dev_name']) ? mysqli_real_escape_string($con, $_GET['filter_dev_name']) : '';
    $filter_project_id = isset($_GET['filter_project_id']) ? mysqli_real_escape_string($con, $_GET['filter_project_id']) : '';
    $filter_start_date = isset($_GET['filter_start_date']) ? mysqli_real_escape_string($con, $_GET['filter_start_date']) : '';
    $filter_end_date = isset($_GET['filter_end_date']) ? mysqli_real_escape_string($con, $_GET['filter_end_date']) : '';
    $filter_interval = isset($_GET['filter_interval']) ? mysqli_real_escape_string($con, $_GET['filter_interval']) : '';

    $where_clause = "WHERE 1=1";
    if (!empty($filter_dev_name)) {
        $where_clause .= " AND p.developer_id = '$filter_dev_name'";
    }
    if (!empty($filter_project_id)) {
        $where_clause .= " AND p.project_id = '$filter_project_id'";
    }
    if (!empty($filter_start_date) && !empty($filter_end_date)) {
        $where_clause .= " AND p.assign_date BETWEEN '$filter_start_date' AND '$filter_end_date'";
    } elseif (!empty($filter_start_date)) {
        $where_clause .= " AND p.assign_date >= '$filter_start_date'";
    } elseif (!empty($filter_end_date)) {
        $where_clause .= " AND p.assign_date <= '$filter_end_date'";
    }

    if (!empty($filter_interval)) {
        $date_format = '';
        switch ($filter_interval) {
            case 'daily':
                $date_format = '%m/%d/%Y';
                break;
            case 'weekly':
                $date_format = '%m/%d/%Y';
                break;
            case 'monthly':
                $date_format = '%m/%Y';
                break;
            case 'yearly':
                $date_format = '%Y';
                break;
        }
        if ($date_format) {
            $where_clause .= " AND DATE_FORMAT(p.assign_date, '$date_format') = DATE_FORMAT(NOW(), '$date_format')";
        }
    }

    $limit = 10;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $start = ($page - 1) * $limit;

    $count_query = "
        SELECT COUNT(*) AS total 
        FROM live_project p
        JOIN developer d ON p.developer_id = d.id
        JOIN project pr ON p.project_id = pr.id
        $where_clause
    ";
    $count_result = mysqli_query($con, $count_query);
    $count_row = mysqli_fetch_assoc($count_result);
    $total_records = $count_row['total'];
    $total_pages = ceil($total_records / $limit);

    $query = "
        SELECT p.*, d.developer_name, pr.project_name 
        FROM live_project p
        JOIN developer d ON p.developer_id = d.id
        JOIN project pr ON p.project_id = pr.id
        $where_clause
        ORDER BY p.assign_date DESC, p.project_id DESC
        LIMIT $start, $limit
    ";

    $live_result = mysqli_query($con, $query);

    $developer_query = "SELECT id, developer_name FROM developer ORDER BY id DESC";
    $developer_result = mysqli_query($con, $developer_query);
    $developers = [];
    while ($row = mysqli_fetch_assoc($developer_result)) {
        $developers[] = $row;
    }

    $project_query = "SELECT id, project_name FROM project ORDER BY id DESC";
    $project_result = mysqli_query($con, $project_query);
    $projects = [];
    while ($row = mysqli_fetch_assoc($project_result)) {
        $projects[] = $row;
    }
    
    $start_entry = $start + 1;
    $end_entry = min($start + $limit, $total_records);
    $entries_text = "Showing $start_entry to $end_entry of $total_records entries";
    ?>

    <h2 class="mt-3 ml-5 headings my-fil">Filter Live Projects!</h2>
    <form method="GET" action="" class="filter-form main-filter">
        <div class="form-group">
            <label for="filter_dev_name">Developer Name on Live Projects:</label>
            <select name="filter_dev_name" id="filter_dev_name" class="form-control">
                <option value="">All Developers</option>
                <?php foreach ($developers as $developer): ?>
                    <option value="<?= $developer['id']; ?>" <?= $filter_dev_name == $developer['id'] ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($developer['developer_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="filter_project_id">Live Projects Name:</label>
            <select name="filter_project_id" id="filter_project_id" class="form-control">
                <option value="">All Projects</option>
                <?php foreach ($projects as $project): ?>
                    <option value="<?= $project['id']; ?>" <?= $filter_project_id == $project['id'] ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($project['project_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="filter_start_date">Start Date:</label>
            <input type="date" name="filter_start_date" id="filter_start_date" value="<?= htmlspecialchars($filter_start_date); ?>" class="form-control">
        </div>

        <div class="form-group">
            <label for="filter_end_date">End Date:</label>
            <input type="date" name="filter_end_date" id="filter_end_date" value="<?= htmlspecialchars($filter_end_date); ?>" class="form-control">
        </div>

        <div class="form-group">
            <label for="filter_interval">Interval:</label>
            <select name="filter_interval" id="filter_interval" class="form-control">
                <option value="">Select Interval</option>
                <option value="daily" <?= $filter_interval == 'daily' ? 'selected' : ''; ?>>Daily</option>
                <option value="weekly" <?= $filter_interval == 'weekly' ? 'selected' : ''; ?>>Weekly</option>
                <option value="monthly" <?= $filter_interval == 'monthly' ? 'selected' : ''; ?>>Monthly</option>
                <option value="yearly" <?= $filter_interval == 'yearly' ? 'selected' : ''; ?>>Yearly</option>
            </select>
        </div>

        <button type="submit" class="my-submit-btn btn btn-primary filter-btn">Filter</button>
    </form>

    <h2 class="mt-3 ml-5 mb-4 headings">Live Project Details</h2>

    <table class="table">
        <thead>
            <tr>
                <th>Serial No.</th>
                <th>Developer Name</th>
                <th>Project Name</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($live_result) > 0) {
                $serial_number = $start + 1;
                while ($live_pro_row = mysqli_fetch_array($live_result)) {
                    $formatted_date = date('m/d/Y', strtotime($live_pro_row['assign_date']));
                    echo "<tr>
                            <td class='my-tds'>" . $serial_number . "</td>
                            <td>" . htmlspecialchars($live_pro_row['developer_name']) . "</td>
                            <td>" . htmlspecialchars($live_pro_row['project_name']) . "</td>
                            <td>" . htmlspecialchars($formatted_date) . "</td>
                            <td class='actions-btn'>
                                <a href='update.php?id=" . $live_pro_row['id'] . "' class='total-btn my-btns edit btn btn-md'>Update</a>
                                <a href='delete.php?id=" . $live_pro_row['id'] . "' class='delete btn btn-md delete-btn total-btn'>Delete</a>
                            </td>
                        </tr>";
                    $serial_number++;
                }
            } else {
                echo "<tr><td colspan='5'>No Live Projects found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
    <div class="row">
        <div class="col-md-6 project-number">
            <div class="entries-info mt-3 ml-5">
                <p><?= $entries_text; ?></p>
            </div>
        </div>
        <div class="col-md-6 pagination">
            <nav aria-label="Page navigation">
                <ul class="pagination">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $page - 1; ?><?= $filter_params; ?>" aria-label="Previous">Previous
                                <span aria-hidden="true"></span>
                            </a>
                        </li>
                    <?php endif; ?>
        
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?= $i; ?><?= $filter_params; ?>"><?= $i; ?></a>
                        </li>
                    <?php endfor; ?>
        
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $page + 1; ?><?= $filter_params; ?>" aria-label="Next">Next
                                <span aria-hidden="true"></span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>

<?php
    require_once('../include/footer.php');
?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const deleteButtons = document.querySelectorAll('.delete-btn');
    
            deleteButtons.forEach(button => {
                button.addEventListener('click', function (event) {
                    event.preventDefault();
                    const url = this.getAttribute('href');
    
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = url;
                        }
                    });
                });
            });
        });
    </script>
    
    
    <!--LIVE CHART SCRIPT STARTED-->

    <script>
    
        document.addEventListener('DOMContentLoaded', function() {
            var dailyData = <?php echo json_encode($daily_data); ?>;
            var weeklyData = <?php echo json_encode($weekly_data); ?>;
            var monthlyData = <?php echo json_encode($monthly_data); ?>;
            var yearlyData = <?php echo json_encode($yearly_data); ?>;
    
            var ctxDaily = document.getElementById('dailyChartCanvas').getContext('2d');
            var dailyChart = new Chart(ctxDaily, {
                type: 'bar',
                data: {
                    labels: dailyData.map(item => item.date),
                    datasets: [{
                        label: 'Daily Projects Added',
                        data: dailyData.map(item => item.count),
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: { beginAtZero: true },
                        y: { beginAtZero: true }
                    }
                }
            });
    
            var ctxWeekly = document.getElementById('weeklyChartCanvas').getContext('2d');
            var weeklyChart = new Chart(ctxWeekly, {
                type: 'bar',
                data: {
                    labels: weeklyData.map(item => 'Week ' + item.week + ', ' + item.year),
                    datasets: [{
                        label: 'Weekly Projects Added',
                        data: weeklyData.map(item => item.count),
                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: { beginAtZero: true },
                        y: { beginAtZero: true }
                    }
                }
            });
    
            var ctxMonthly = document.getElementById('monthlyChartCanvas').getContext('2d');
            var monthlyChart = new Chart(ctxMonthly, {
                type: 'bar',
                data: {
                    labels: monthlyData.map(item => 'Month ' + item.month + ', ' + item.year),
                    datasets: [{
                        label: 'Monthly Projects Added',
                        data: monthlyData.map(item => item.count),
                        backgroundColor: 'rgba(255, 159, 64, 0.2)',
                        borderColor: 'rgba(255, 159, 64, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: { beginAtZero: true },
                        y: { beginAtZero: true }
                    }
                }
            });
    
            var ctxYearly = document.getElementById('yearlyChartCanvas').getContext('2d');
            var yearlyChart = new Chart(ctxYearly, {
                type: 'bar',
                data: {
                    labels: yearlyData.map(item => item.year),
                    datasets: [{
                        label: 'Yearly Projects Added',
                        data: yearlyData.map(item => item.count),
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        x: { beginAtZero: true },
                        y: { beginAtZero: true }
                    }
                }
            });
        });
    </script>


    <!--LIVE CHART SCRIPT ENDED-->