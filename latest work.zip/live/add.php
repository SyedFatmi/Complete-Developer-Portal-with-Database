<?php
    require_once('../include/connection.php');
    require_once('../include/header.php');
    
    if (isset($_POST['live-pro-submit'])) {
      $liveprojectName = $_POST['live-pro-name'];
      $livedeveloperName = $_POST['live-dev-name'];
      $liveassignDate = $_POST['live-assign-date'];
      
      $query = "INSERT INTO `live_project`(`developer_id`, `project_id`, `assign_date`) VALUES ('$livedeveloperName','$liveprojectName','$liveassignDate')";
      $liveproInsert = mysqli_query($con, $query);

      if($liveproInsert){
          echo "<script>window.location.href = 'index.php';</script>";
      }
       die();
    }
?>

            <?php 
                require_once('../include/sidebar.php');
            ?>

            <div class="col-md-10">
                <form class="project-form" method="POST">
                <h2 class="headings">Add Live Projects!</h2>
                  <div class="form-group">
                    <label>Live Project Name</label>
                    <select id="live-pro-name" name="live-pro-name" class="form-control" required>
		            	<?php 
		            		$query = "SELECT * FROM `project`";
		            		$mysqli = mysqli_query($con, $query);
		            		while($pro_dev = mysqli_fetch_assoc($mysqli)) {
		            			echo "<option value = ". $pro_dev['id'] .">". $pro_dev['project_name'] ."</option>";
		            		}
		            	?>
					</select>
                  </div>
                  <div class="form-group">
                    <label>Developer Name on live Project</label>
                    <select id="live-dev-name" name="live-dev-name" class="form-control" required>
		            	<?php 
		            		$query = "SELECT * FROM `developer`";
		            		$mysqli = mysqli_query($con, $query);
		            		while($dev = mysqli_fetch_assoc($mysqli)) {
		            			echo "<option value = ". $dev['id'] .">". $dev['developer_name'] ."</option>";
		            		}
		            	?>
					</select>
                  </div>
                  <div class="form-group">
                    <label>Assign Date</label>
                    <input type="date" class="form-control" id="live-assign-date" name="live-assign-date" placeholder="Assige Date" required>
                  </div>
                  <button id="addProject" type="submit" class="mb-5 btn btn-primary filter-btn" name="live-pro-submit" onclick='confirmliveaddProject()'>Add Live Project</button>
                </form>
            </div>
        </div>
    </div>


<?php
    require_once('../include/footer.php');
?>


    </script>
        <script>
        function confirmliveaddProject(id) {
            Swal.fire({
                title: 'Added Successfully!',
                text: "Your Live Project Added!",
                icon: 'success',
                showConfirmButton:false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '/projectdetail.php?id=' + id;
                }
            })
        }
    </script>