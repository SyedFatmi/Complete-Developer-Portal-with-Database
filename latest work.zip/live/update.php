<?php
    require_once('../include/connection.php');
    require_once('../include/header.php');
    require_once('../include/sidebar.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $project_id = isset($_POST['update-pro-name']) ? (int)$_POST['update-pro-name'] : 0;
    $developer_id = isset($_POST['update-dev-name']) ? (int)$_POST['update-dev-name'] : 0;
    $assign_date = isset($_POST['updateassign-date']) ? $_POST['updateassign-date'] : '';

    if ($id > 0) {

        $query = "UPDATE live_project SET project_id = $project_id, developer_id = $developer_id, assign_date = $assign_date WHERE id = $id";
        $stmt = $con->prepare($query);
        if ($stmt === false) {
            die('Prepare failed: ' . htmlspecialchars($con->error));
        }

        $stmt->bind_param('iisi', $project_id, $developer_id, $assign_date, $id);

        if ($stmt->execute()) {
            header('Location: index.php');
            exit;
        } else {
            header('Location: update.php?error=1');
            exit;
        }
        $stmt->close();
    }
}

$update_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$update_pro_result = [];
$update_dev_result = [];

if ($update_id > 0) {

    $query = "SELECT * FROM live_project WHERE id = ?";
    $stmt = $con->prepare($query);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($con->error));
    }
    
    $stmt->bind_param('i', $update_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $update_pro_result = $result->fetch_assoc();
    $stmt->close();

    if (isset($update_pro_result['developer_id'])) {
        $dev_id = (int)$update_pro_result['developer_id'];
        $query = "SELECT * FROM developer WHERE id = ?";
        $stmt = $con->prepare($query);
        if ($stmt === false) {
            die('Prepare failed: ' . htmlspecialchars($con->error));
        }
        
        $stmt->bind_param('i', $dev_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $update_dev_result = $result->fetch_assoc();
        $stmt->close();
    }
}
?>

<div class="col-md-10">
    <h2 class="mt-5 ml-5 chart-heading">Update Live Project</h2>

    <form class="project-form" method="POST" action="">
        <div class="form-group">
            <label for="update-pro-name">Live Project Name</label>
            <select id="update-pro-name" name="update-pro-name" class="form-control">
                <?php
                $projects_query = "SELECT id, project_name FROM project";
                $projects_result = mysqli_query($con, $projects_query);
                while ($updatepro = mysqli_fetch_assoc($projects_result)) {
                    $selected = $updatepro['id'] == $update_pro_result['project_id'] ? 'selected' : '';
                    echo "<option value='{$updatepro['id']}' $selected>" . htmlspecialchars($updatepro['project_name']) . "</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="update-dev-name">Developer Name on Live Project</label>
            <select id="update-dev-name" name="update-dev-name" class="form-control">
                <?php
                $developers_query = "SELECT id, developer_name FROM developer";
                $developers_result = mysqli_query($con, $developers_query);
                while ($prodev = mysqli_fetch_assoc($developers_result)) {
                    $selected = $prodev['id'] == $update_dev_result['id'] ? 'selected' : '';
                    echo "<option value='{$prodev['id']}' $selected>" . htmlspecialchars($prodev['developer_name']) . "</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="update-assign-date">Assign Date</label>
            <input type="date" class="form-control" id="update-assign-date" name="updateassign-date" value="<?php echo htmlspecialchars($update_pro_result['assign_date']); ?>">
        </div>
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($update_pro_result['id']); ?>">
        <button id="updateProject" type="submit" class="mb-5 btn btn-primary filter-btn">Update Project</button>
    </form>
</div>

<?php
require_once('../include/footer.php');
?>
