<?php
    require_once('header.php');
?>

<?php 
    require_once('sidebar.php');
?>

<?php
    $daily_query = "SELECT DATE(assign_date) as date, COUNT(*) as count FROM project p $where_clause GROUP BY DATE(assign_date)";
    $daily_result = mysqli_query($con, $daily_query);
    $daily_data = [];
    while ($row = mysqli_fetch_assoc($daily_result)) {
        $daily_data[] = $row;
    }
    
    $weekly_query = "SELECT YEAR(assign_date) as year, WEEK(assign_date) as week, COUNT(*) as count FROM project p $where_clause GROUP BY YEAR(assign_date), WEEK(assign_date)";
    $weekly_result = mysqli_query($con, $weekly_query);
    $weekly_data = [];
    while ($row = mysqli_fetch_assoc($weekly_result)) {
        $weekly_data[] = $row;
    }
    
    $monthly_query = "SELECT YEAR(assign_date) as year, MONTH(assign_date) as month, COUNT(*) as count FROM project p $where_clause GROUP BY YEAR(assign_date), MONTH(assign_date)";
    $monthly_result = mysqli_query($con, $monthly_query);
    $monthly_data = [];
    while ($row = mysqli_fetch_assoc($monthly_result)) {
        $monthly_data[] = $row;
    }
    
    $yearly_query = "SELECT YEAR(assign_date) as year, COUNT(*) as count FROM project p $where_clause GROUP BY YEAR(assign_date)";
    $yearly_result = mysqli_query($con, $yearly_query);
    $yearly_data = [];
    while ($row = mysqli_fetch_assoc($yearly_result)) {
        $yearly_data[] = $row;
    }
?>

    <div class="col-md-12">
        <h1 class="total-entries mt-5 mb-4 ml-5">Total Projects Entries</h1>
        <h2 class="mt-0 ml-5 chart-heading">Chart Detail Shows Daily, Weekly, Monthly and Yearly Projects.</h2>
        <div class="row my-charts">
            <div class="col-md-3">
                <h2 class="projects-added">Daily Projects Added</h2>
                <canvas id="dailyChart"></canvas>
            </div>
            <div class="col-md-3">
                <h2 class="projects-added">Weekly Projects Added</h2>
                <canvas id="weeklyChart"></canvas>
            </div>
            <div class="col-md-3">
                <h2 class="projects-added">Monthly Projects Added</h2>
                <canvas id="monthlyChart"></canvas>
            </div>
            <div class="col-md-3">
                <h2 class="projects-added">Yearly Projects Added</h2>
                <canvas id="yearlyChart"></canvas>
            </div>
        </div>
    </div>
    
<?php
    require_once('footer.php');
?>
