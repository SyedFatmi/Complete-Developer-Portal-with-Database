<?php
$con = mysqli_connect("localhost","dotgrace_dev_user","E7^X3W^+$1Fr","dotgrace_dev_db");

// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

?>



