
  <body>
    <div class="container-fluid">
        <div class="row">
            
            <div class="col-md-2 my-sidebar">
                <a href="/"><img src="../assets/images/logo.png" /></a>;
                <a href="/" class="my-btn"><i class="fa-solid fa-house"></i> Home</a>
                <a href="/developer" class="my-btn"><i class="fa-solid fa-user-pen"></i> Add Developers</a>
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa-solid fa-list-check"></i> Projects
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="/projects/add.php">
                            <i class="fas fa-plus"></i> Add Projects
                        </a>
                        <a class="dropdown-item" href="/projects/">
                            <i class="fas fa-info-circle"></i> Projects Detail
                        </a>
                    </div>
                </div>
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa-solid fa-address-book"></i>Live Projects
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="/live/add.php">
                            <i class="fas fa-plus"></i> Add Live Projects
                        </a>
                        <a class="dropdown-item" href="/live/">
                            <i class="fas fa-info-circle"></i> Live Projects Detail
                        </a>
                    </div>
                </div>
            </div>
            
