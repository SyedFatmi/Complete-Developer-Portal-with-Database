<?php 
    require_once('../include/connection.php');

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM `project` WHERE id = $id";
    $result = mysqli_query($con, $query);
    if($result) {
        echo "<script>window.location.href = 'index.php';</script>";
    }
}

?>
