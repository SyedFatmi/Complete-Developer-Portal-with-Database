<?php
    require_once('../include/connection.php');
    require_once('../include/header.php');
    
    if(isset($_GET['id'])) {
		$id = $_GET['id'];
		$query = "SELECT * FROM `project` WHERE id = $id";
		$mysqli_query = mysqli_query($con, $query);
		$pro_result = mysqli_fetch_assoc($mysqli_query);
	}
	
	if (isset($_POST['pro-update'])) {
		$projectName = $_POST['project-name'];
		$developerName = $_POST['dev-name'];
		$assignDate = $_POST['assign-date']; 
		$pro_id = $_POST['id'];

		$query = "UPDATE `project` SET `developer_id`='$developerName',`project_name`='$projectName',`assign_date`='$assignDate' WHERE id = $pro_id";
		$dev_updated = mysqli_query($con, $query);
		if($dev_updated) {
			echo "<script>window.location.href = 'index.php';</script>";
		}
	}
?>

            <?php 
                require_once('../include/sidebar.php');
            ?>


            <div class="col-md-10">
                <form class="project-form" method="POST">
                <h2 class="headings">Update your Projects!</h2>
                  <div class="form-group">
                    <label>Project Name</label>
                    <input type="text" class="form-control" id="project-name" name="project-name" value="<?php echo $pro_result['project_name']; ?>">
                  </div>
                  <div class="form-group">
                    <label>Developer Name</label>
                    <select id="dev-name" name="dev-name" class="form-control">
		            	<?php 
		            		$query = "SELECT * FROM `developer`";
		            		$mysqli = mysqli_query($con, $query);
		            		while($prodev = mysqli_fetch_assoc($mysqli)) {
		            		if($prodev['id'] == $pro_result['developer_id']){
		            			echo "<option value = ". $prodev['id'] ." selected>". $prodev['developer_name'] ."</option>";
		            		}else{
		            			echo "<option value = ". $prodev['id'] .">". $prodev['developer_name'] ."</option>";	
		            		}
		            		}
		            	?>
					</select>
                  </div>
                  <div class="form-group">
                    <label>Assign Date</label>
                    <input type="date" class="form-control" id="assign-date" name="assign-date" value="<?php echo $pro_result['assign_date']; ?>">
                  </div>
                  <input type="hidden" name="id" value="<?php echo $pro_result['id']; ?>">
                  <button id="updateProject" type="submit" class="mb-5 btn btn-primary filter-btn" name="pro-update" onclick='confirmupdateProject()'>Update Project</button>
                </form>
            </div>
        </div>
    </div>

<?php
    require_once('../include/footer.php')
?>


    <script>
        function confirmupdateProject(id) {
            Swal.fire({
                title: 'Update Successfully!',
                text: "Your Project Updated!",
                icon: 'success',
                showConfirmButton:false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '/index.php?id=' + id;
                }
            })
        }
    </script>