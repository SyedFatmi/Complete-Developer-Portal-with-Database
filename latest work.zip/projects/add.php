<?php
    require_once('../include/connection.php');
    require_once('../include/header.php');
    
    if (isset($_POST['pro-submit'])) {
      $projectName = $_POST['project-name'];
      $developerName = $_POST['dev-name'];
      $assignDate = $_POST['assign-date'];
      
      $query = "INSERT INTO `project`(`developer_id`, `project_name`, `assign_date`) VALUES ('$developerName','$projectName','$assignDate')";
      $proInsert = mysqli_query($con, $query);

      if($proInsert){
          echo "<script>window.location.href = 'index.php';</script>";
      }
       die();
    }
    
    if (isset($_POST['employee-submit'])) {
      $dev_name = $_POST['dev-name'];
      $employee_id = $_POST['emp-id'];

       $query = "INSERT INTO `developer`(`developer_name`, `employee_id`) VALUES ('$dev_name','$employee_id')";
       $insert = mysqli_query($con, $query);

       if($insert){
          echo "<script>alert('Developer Added Success');window.location.href = 'developer.php';</script>";
       }
       die();
    }
?>

            <?php 
                require_once('../include/sidebar.php');
            ?>

            <div class="col-md-10">
                <form class="project-form" method="POST">
                <h2 class="headings">Add your Projects!</h2>
                  <div class="form-group">
                    <label>Project Name</label>
                    <input type="text" class="form-control" id="project-name" name="project-name" placeholder="Project Name" required>
                  </div>
                  <div class="form-group">
                    <label>Developer Name</label>
                    <select id="dev-name" name="dev-name" class="form-control" required>
		            	<?php 
		            		$query = "SELECT * FROM `developer`";
		            		$mysqli = mysqli_query($con, $query);
		            		while($dev = mysqli_fetch_assoc($mysqli)) {
		            			echo "<option value = ". $dev['id'] .">". $dev['developer_name'] ."</option>";
		            		}
		            	?>
					</select>
                  </div>
                  <div class="form-group">
                    <label>Assign Date</label>
                    <input type="date" class="form-control" id="assign-date" name="assign-date" placeholder="Assige Date" required>
                  </div>
                  <button id="addProject" type="submit" class="mb-5 btn btn-primary filter-btn" name="pro-submit" onclick='confirmaddProject()'>Add Project</button>
                </form>
            </div>
        </div>
    </div>


<?php
    require_once('../include/footer.php');
?>

    <script>
        function confirmaddProject(id) {
            Swal.fire({
                title: 'Added Successfully!',
                text: "Your Project Added!",
                icon: 'success',
                showConfirmButton:false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '/projectdetail.php?id=' + id;
                }
            })
        }
    </script>