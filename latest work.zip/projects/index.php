<?php
    require_once('../include/connection.php');
    require_once('../include/header.php');
?>

            <?php 
                require_once('../include/sidebar.php');
            ?>
            <div class="col-md-10">
                <h2 class="mt-5 ml-5 chart-heading">Chart Detail Shows Daily, Weekly, Monthly and Yearly Projects.</h2>
            
                <div class="row my-charts">
                    <div class="col-md-3">
                        <h2 class="projects-added">Daily Projects Added</h2>
                        <canvas id="dailyChart"></canvas>
                    </div>
                    <div class="col-md-3">
                        <h2 class="projects-added">Weekly Projects Added</h2>
                        <canvas id="weeklyChart"></canvas>
                    </div>
                    <div class="col-md-3">
                        <h2 class="projects-added">Monthly Projects Added</h2>
                        <canvas id="monthlyChart"></canvas>
                    </div>
                    <div class="col-md-3">
                        <h2 class="projects-added">Yearly Projects Added</h2>
                        <canvas id="yearlyChart"></canvas>
                    </div>
                </div>

            
                <?php
                
                if (isset($_POST['import_csv'])) {
                    $fileName = $_FILES['csv_file']['tmp_name'];
                
                    if ($_FILES['csv_file']['size'] > 0) {
                        $file = fopen($fileName, 'r');
                
                        $header = fgetcsv($file, 10000, ",");
                
                        $success_messages = [];
                        $error_messages = [];  
                
                        while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
                            $developer_name = mysqli_real_escape_string($con, $column[0]);
                            $project_name = mysqli_real_escape_string($con, $column[1]);
                            $assign_date = mysqli_real_escape_string($con, $column[2]);
                
                            $check_dev_query = "SELECT id FROM developer WHERE developer_name = '$developer_name' LIMIT 1";
                            $dev_result = mysqli_query($con, $check_dev_query);
                
                            if (mysqli_num_rows($dev_result) > 0) {
                                $dev_row = mysqli_fetch_assoc($dev_result);
                                $developer_id = $dev_row['id'];
                            } else {

                                $employee_id_query = "SELECT MAX(id) + 1 AS new_employee_id FROM developer";
                                $employee_id_result = mysqli_query($con, $employee_id_query);
                                $employee_id_row = mysqli_fetch_assoc($employee_id_result);
                                $employee_id = $employee_id_row['new_employee_id'] ?? 1;
                
                                $insert_dev_query = "INSERT INTO developer (developer_name, employee_id) VALUES ('$developer_name', '$employee_id')";
                                mysqli_query($con, $insert_dev_query);
                                $developer_id = mysqli_insert_id($con); 
                
                                $success_messages[] = "Developer '$developer_name' created successfully.";
                            }
                
                            $check_proj_query = "SELECT id FROM project WHERE project_name = '$project_name' LIMIT 1";
                            $proj_result = mysqli_query($con, $check_proj_query);
                
                            if (mysqli_num_rows($proj_result) > 0) {

                                $error_messages[] = "Project '$project_name' already exists and cannot be assigned again.";
                            } else {

                                $formatted_date = date('Y-m-d', strtotime($assign_date));
                                $insert_project_query = "INSERT INTO project (developer_id, project_name, assign_date) VALUES ('$developer_id', '$project_name', '$formatted_date')";
                                mysqli_query($con, $insert_project_query);
                
                                $success_messages[] = "Project '$project_name' assigned to '$developer_name' successfully.";
                            }
                        }
                
                        fclose($file);
                
                        if (!empty($success_messages)) {
                            foreach ($success_messages as $message) {
                                echo "<p class='alert alert-success width'>$message</p>";
                            }
                        }
                
                        if (!empty($error_messages)) {
                            foreach ($error_messages as $message) {
                                echo "<p class='alert alert-danger width'>$message</p>";
                            }
                        }
                
                    } else {
                        echo "<p class='alert alert-warning width'>Please upload a valid CSV file.</p>";
                    }
                }
                
                
                // if (isset($_POST['import_csv'])) {
                //     $fileName = $_FILES['csv_file']['tmp_name'];
                
                //     if ($_FILES['csv_file']['size'] > 0) {
                //         $file = fopen($fileName, 'r');
                //         $header = fgetcsv($file, 10000, ",");
                
                //         $success_messages = [];
                //         $error_messages = [];
                
                //         while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
                //             $developer_name = mysqli_real_escape_string($con, $column[0]);
                //             $project_name = mysqli_real_escape_string($con, $column[1]);
                //             $assign_date = mysqli_real_escape_string($con, $column[2]);
                
                //             $check_dev_query = "SELECT id FROM developer WHERE developer_name = '$developer_name' LIMIT 1";
                //             $dev_result = mysqli_query($con, $check_dev_query);
                
                //             if (mysqli_num_rows($dev_result) > 0) {
                //                 $dev_row = mysqli_fetch_assoc($dev_result);
                //                 $developer_id = $dev_row['id'];
                //             } else {
                //                 $employee_id_query = "SELECT MAX(id) + 1 AS new_employee_id FROM developer";
                //                 $employee_id_result = mysqli_query($con, $employee_id_query);
                //                 $employee_id_row = mysqli_fetch_assoc($employee_id_result);
                //                 $employee_id = $employee_id_row['new_employee_id'] ?? 1;
                
                //                 $insert_dev_query = "INSERT INTO developer (developer_name, employee_id) VALUES ('$developer_name', '$employee_id')";
                //                 mysqli_query($con, $insert_dev_query);
                //                 $developer_id = mysqli_insert_id($con);
                
                //                 $success_messages[] = "Developer '$developer_name' created successfully.";
                //             }
                
                //             $check_proj_query = "SELECT id FROM project WHERE project_name = '$project_name' LIMIT 1";
                //             $proj_result = mysqli_query($con, $check_proj_query);
                
                //             if (mysqli_num_rows($proj_result) > 0) {
                //                 $error_messages[] = "Project '$project_name' already exists and cannot be assigned again.";
                //             } else {
                //                 $formatted_date = date('Y-m-d', strtotime($assign_date));
                //                 $insert_project_query = "INSERT INTO project (developer_id, project_name, assign_date) VALUES ('$developer_id', '$project_name', '$formatted_date')";
                //                 mysqli_query($con, $insert_project_query);
                
                //                 $success_messages[] = "Project '$project_name' assigned to '$developer_name' successfully.";
                //             }
                //         }
                
                //         fclose($file);
                
                //         if (!empty($success_messages) || !empty($error_messages)) {
                //             echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
                //             echo "<script>";
                            
                //             if (!empty($success_messages)) {
                //                 foreach ($success_messages as $message) {
                //                     echo "Swal.fire({
                //                         icon: 'success',
                //                         title: 'Success',
                //                         text: '$message'
                //                     });";
                //                 }
                //             }
                
                //             if (!empty($error_messages)) {
                //                 foreach ($error_messages as $message) {
                //                     echo "Swal.fire({
                //                         icon: 'error',
                //                         title: 'Error',
                //                         text: '$message'
                //                     });";
                //                 }
                //             }
                
                //             echo "</script>";
                //         }
                //     } else {
                //         echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
                //         echo "<script>
                //             Swal.fire({
                //                 icon: 'warning',
                //                 title: 'Warning',
                //                 text: 'Please upload a valid CSV file.'
                //             });
                //         </script>";
                //     }
                // }

                
                
                $filter_dev_name = isset($_GET['filter_dev_name']) ? mysqli_real_escape_string($con, $_GET['filter_dev_name']) : '';
                $filter_project_name = isset($_GET['filter_project_name']) ? mysqli_real_escape_string($con, $_GET['filter_project_name']) : '';
                $filter_start_date = isset($_GET['filter_start_date']) ? mysqli_real_escape_string($con, $_GET['filter_start_date']) : '';
                $filter_end_date = isset($_GET['filter_end_date']) ? mysqli_real_escape_string($con, $_GET['filter_end_date']) : '';
                $filter_interval = isset($_GET['filter_interval']) ? mysqli_real_escape_string($con, $_GET['filter_interval']) : '';
                
                $where_clause = "WHERE 1=1";
                
                if (!empty($filter_dev_name)) {
                    $where_clause .= " AND p.developer_id = '$filter_dev_name'";
                }
                
                if (!empty($filter_project_name)) {
                    $where_clause .= " AND p.project_name LIKE '%$filter_project_name%'";
                }
                
                if (!empty($filter_start_date) && !empty($filter_end_date)) {
                    $where_clause .= " AND p.assign_date BETWEEN '$filter_start_date' AND '$filter_end_date'";
                } 
                
                elseif (!empty($filter_start_date)) {
                    $where_clause .= " AND p.assign_date >= '$filter_start_date'";
                } 
                
                elseif (!empty($filter_end_date)) {
                    $where_clause .= " AND p.assign_date <= '$filter_end_date'";
                }
                
                if (!empty($filter_interval)) {
                    $date_format = '';
                    switch ($filter_interval) {
                        case 'daily':
                            $date_format = '%m/%d/%Y';
                            break;
                        case 'weekly':
                            $date_format = '%m/%d/%Y'; 
                            break;
                        case 'monthly':
                            $date_format = '%m/%Y'; 
                            break;
                        case 'yearly':
                            $date_format = '%Y';
                            break;
                    }
                    if ($date_format) {
                        $where_clause .= " AND DATE_FORMAT(p.assign_date, '$date_format') = DATE_FORMAT(NOW(), '$date_format')";
                    }
                }
                
                $limit = 10;
                $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                $start = ($page - 1) * $limit;
                
                $count_query = "
                    SELECT COUNT(*) AS total 
                    FROM project p
                    JOIN developer d ON p.developer_id = d.id
                    $where_clause
                ";
                $count_result = mysqli_query($con, $count_query);
                $count_row = mysqli_fetch_assoc($count_result);
                $total_records = $count_row['total'];
                $total_pages = ceil($total_records / $limit);
                
                $start_record = $start + 1;
                $end_record = min($start + $limit, $total_records);
                
                $query = "
                    SELECT p.*, d.developer_name 
                    FROM project p
                    JOIN developer d ON p.developer_id = d.id
                    $where_clause
                    ORDER BY p.id DESC, p.assign_date DESC
                    LIMIT $start, $limit
                ";


                $result = mysqli_query($con, $query);
                
                $developer_query = "SELECT id, developer_name FROM developer ORDER BY id DESC";
                $developer_result = mysqli_query($con, $developer_query);
                $developers = [];
                while ($row = mysqli_fetch_assoc($developer_result)) {
                    $developers[] = $row;
                }

                $daily_query = "SELECT DATE(assign_date) as date, COUNT(*) as count FROM project p $where_clause GROUP BY DATE(assign_date)";
                $daily_result = mysqli_query($con, $daily_query);
                $daily_data = [];
                while ($row = mysqli_fetch_assoc($daily_result)) {
                    $daily_data[] = $row;
                }
                
                $weekly_query = "SELECT YEAR(assign_date) as year, WEEK(assign_date) as week, COUNT(*) as count FROM project p $where_clause GROUP BY YEAR(assign_date), WEEK(assign_date)";
                $weekly_result = mysqli_query($con, $weekly_query);
                $weekly_data = [];
                while ($row = mysqli_fetch_assoc($weekly_result)) {
                    $weekly_data[] = $row;
                }
                
                $monthly_query = "SELECT YEAR(assign_date) as year, MONTH(assign_date) as month, COUNT(*) as count FROM project p $where_clause GROUP BY YEAR(assign_date), MONTH(assign_date)";
                $monthly_result = mysqli_query($con, $monthly_query);
                $monthly_data = [];
                while ($row = mysqli_fetch_assoc($monthly_result)) {
                    $monthly_data[] = $row;
                }
                
                $yearly_query = "SELECT YEAR(assign_date) as year, COUNT(*) as count FROM project p $where_clause GROUP BY YEAR(assign_date)";
                $yearly_result = mysqli_query($con, $yearly_query);
                $yearly_data = [];
                while ($row = mysqli_fetch_assoc($yearly_result)) {
                    $yearly_data[] = $row;
                }
                
                ?>
                <h2 class="mt-3 ml-5 headings">If you want add bulk projects use CSV file upload option to save your time!</h2>
                <form method="POST" action="" enctype="multipart/form-data" class="mb-3 import-form">
                    <div class="form-group">
                        <label for="csv_file">Import CSV:</label>
                        <input type="file" name="csv_file" id="csv_file" class="form-control">
                    </div>
                    <button type="submit" name="import_csv" class="btn btn-primary filter-btn">Import CSV</button>
                </form>
                
                <h2 class="mt-3 ml-5 headings">Filter Projects!</h2>
                <form method="GET" action="" class="filter-form">
                    <div class="form-group dev-name">
                        <label for="filter_dev_name">Developer Name:</label>
                        <select name="filter_dev_name" id="filter_dev_name" class="form-control">
                            <option value="">Select Developer</option>
                            <?php foreach ($developers as $developer) : ?>
                                <option value="<?php echo htmlspecialchars($developer['id']); ?>"
                                    <?php echo ($filter_dev_name == $developer['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($developer['developer_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group emp-id">
                        <label for="filter_project_name">Project Name:</label>
                        <input type="text" name="filter_project_name" id="filter_project_name" value="<?php echo htmlspecialchars($filter_project_name); ?>" class="form-control" placeholder="Enter Correct Project Name">
                    </div>
                    <div class="form-group emp-start-date">
                        <label for="filter_start_date">Start Date:</label>
                        <input type="date" name="filter_start_date" id="filter_start_date" value="<?php echo htmlspecialchars($filter_start_date); ?>" class="form-control">
                    </div>
                    <div class="form-group emp-date">
                        <label for="filter_end_date">End Date:</label>
                        <input type="date" name="filter_end_date" id="filter_end_date" value="<?php echo htmlspecialchars($filter_end_date); ?>" class="form-control">
                    </div>
                    <div class="form-group emp-interval">
                        <label for="filter_interval">Select Time Period:</label>
                        <select name="filter_interval" id="filter_interval" class="form-control">
                            <option value="">Select Period</option>
                            <option value="daily" <?php echo ($filter_interval == 'daily') ? 'selected' : ''; ?>>Daily</option>
                            <option value="weekly" <?php echo ($filter_interval == 'weekly') ? 'selected' : ''; ?>>Weekly</option>
                            <option value="monthly" <?php echo ($filter_interval == 'monthly') ? 'selected' : ''; ?>>Monthly</option>
                            <option value="yearly" <?php echo ($filter_interval == 'yearly') ? 'selected' : ''; ?>>Yearly</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary submit-btn filter-btn">Filter</button>
                </form>
                
                <h2 class="mt-3 ml-5 mb-4 headings">Project Details</h2>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>Serial No.</th> 
                            <th>Developer Name</th>
                            <th>Project Name</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($result) > 0) {
                            $serial_number = $start + 1; 
                            while ($pro_row = mysqli_fetch_array($result)) {
                                $formatted_date = date('m/d/Y', strtotime($pro_row['assign_date']));
                                echo "<tr>
                                        <td class='my-tds'>" . $serial_number . "</td>
                                        <td>" . htmlspecialchars($pro_row['developer_name']) . "</td>
                                        <td>" . htmlspecialchars($pro_row['project_name']) . "</td>
                                        <td>" . htmlspecialchars($formatted_date) . "</td>
                                        <td class='actions-btn'>
                                            <a href='update.php?id=" . $pro_row['id'] . "' class='total-btn my-btns edit btn btn-md'>Update</a>
                                            <a href='delete.php?id=" . $pro_row['id'] . "' class='delete btn btn-md delete-btn total-btn ' onclick='confirmDelete(" . $pro_row['id'] . ")'>Delete</a>
                                        </td>
                                      </tr>";
                                $serial_number++;
                            }
                        } 
                        else {
                            echo "<tr><td colspan='5'>No Project Records Found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
                
                <div class="row">
                    <div class="col-md-6 project-number">
                        <p class="text-muted">Projects <?php echo $start_record; ?> to <?php echo $end_record; ?> out of <?php echo $total_records; ?> total Projects.</p>
                    </div>
                    <div class="col-md-6 pagination">
                        <nav aria-label="Page navigation" class="full-pagination">
                            <ul class="pagination">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page - 1; ?>&filter_dev_name=<?php echo urlencode($filter_dev_name); ?>&filter_project_name=<?php echo urlencode($filter_project_name); ?>&filter_start_date=<?php echo urlencode($filter_start_date); ?>&filter_end_date=<?php echo urlencode($filter_end_date); ?>&filter_interval=<?php echo urlencode($filter_interval); ?>" aria-label="Previous">
                                            Previous
                                        </a>
                                    </li>
                                <?php endif; ?>
                        
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>&filter_dev_name=<?php echo urlencode($filter_dev_name); ?>&filter_project_name=<?php echo urlencode($filter_project_name); ?>&filter_start_date=<?php echo urlencode($filter_start_date); ?>&filter_end_date=<?php echo urlencode($filter_end_date); ?>&filter_interval=<?php echo urlencode($filter_interval); ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                        
                                <?php if ($page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?php echo $page + 1; ?>&filter_dev_name=<?php echo urlencode($filter_dev_name); ?>&filter_project_name=<?php echo urlencode($filter_project_name); ?>&filter_start_date=<?php echo urlencode($filter_start_date); ?>&filter_end_date=<?php echo urlencode($filter_end_date); ?>&filter_interval=<?php echo urlencode($filter_interval); ?>" aria-label="Next">
                                            Next
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
<?php
    require_once('../include/footer.php');
?>


    <!--CHART SCRIPT START-->
    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
    
            const dailyData = <?php echo json_encode($daily_data); ?>;
            const weeklyData = <?php echo json_encode($weekly_data); ?>;
            const monthlyData = <?php echo json_encode($monthly_data); ?>;
            const yearlyData = <?php echo json_encode($yearly_data); ?>;
            
            const dailyCtx = document.getElementById('dailyChart').getContext('2d');
            new Chart(dailyCtx, {
                type: 'bar',
                data: {
                    labels: dailyData.map(item => item.date),
                    datasets: [{
                        label: 'Daily Added',
                        data: dailyData.map(item => item.count),
                        backgroundColor: '#f705ab',
                        borderColor: '#f705ab',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
    
            const weeklyCtx = document.getElementById('weeklyChart').getContext('2d');
            new Chart(weeklyCtx, {
                type: 'bar',
                data: {
                    labels: weeklyData.map(item => `Week ${item.week} of ${item.year}`),
                    datasets: [{
                        label: 'Weekly Added',
                        data: weeklyData.map(item => item.count),
                        backgroundColor: '#05f7cb',
                        borderColor: '#05f7cb',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
    
            const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
            new Chart(monthlyCtx, {
                type: 'bar',
                data: {
                    labels: monthlyData.map(item => `Month ${item.month} of ${item.year}`),
                    datasets: [{
                        label: 'Monthly Added',
                        data: monthlyData.map(item => item.count),
                        backgroundColor: '#31f705',
                        borderColor: '#31f705',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
    
            const yearlyCtx = document.getElementById('yearlyChart').getContext('2d');
            new Chart(yearlyCtx, {
                type: 'bar',
                data: {
                    labels: yearlyData.map(item => item.year),
                    datasets: [{
                        label: 'Yearly Added',
                        data: yearlyData.map(item => item.count),
                        backgroundColor: '#f7bb05',
                        borderColor: '#f7bb05',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>

    <!--CHART SCRIPT ENDED-->
