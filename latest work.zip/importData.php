<?php 

require_once('header.php');

$res_status = $res_msg = ''; 
if (isset($_POST['importSubmit'])) { 
    // Allowed mime types 
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel'); 
    
    // Validate whether selected file is a CSV file 
    if (!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'], $csvMimes)) { 
        
        // If the file is uploaded 
        if (is_uploaded_file($_FILES['file']['tmp_name'])) { 
            
            // Open uploaded CSV file with read-only mode 
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r'); 
            
            // Skip the first line 
            fgetcsv($csvFile); 
            
            // Parse data from CSV file line by line 
            while (($line = fgetcsv($csvFile)) !== FALSE) { 
                $line_arr = !empty($line) ? array_filter($line) : ''; 
                if (!empty($line_arr)) { 
                    // Get row data 
                    $developer_id = trim($line_arr[0]); 
                    $project_name = trim($line_arr[1]); 
                    $assign_date = trim($line_arr[2]); 
                    
                    // Check whether project already exists in the database with the same developer_id
                    $prevQuery = "SELECT id FROM project WHERE developer_id = ".$developer_id."";
                    $stmt = $con->prepare($prevQuery);
                    $stmt->bind_param("s", $developer_id);
                    $stmt->execute();
                    $prevResult = $stmt->get_result();
                    
                    if ($prevResult->num_rows > 0) { 
                        // Update project data in the database 
                        $updateQuery = "UPDATE project SET project_name = ".$project_name.", assign_date = ".$assign_date." WHERE developer_id = ".$developer_id."";
                        $stmt = $con->prepare($updateQuery);
                        $stmt->bind_param("sss", $project_name, $assign_date, $developer_id);
                        $stmt->execute();
                    } else { 
                        // Insert project data in the database 
                        $insertQuery = "INSERT INTO project (developer_id, project_name, assign_date) VALUES (".$developer_id.", ".$project_name.", ".$assign_date.")";
                        $stmt = $con->prepare($insertQuery);
                        $stmt->bind_param("ssss", $developer_id, $project_name, $assign_date, $status);
                        $stmt->execute();
                    } 
                } 
            } 
            
            // Close opened CSV file 
            fclose($csvFile); 
            
            $res_status = 'success'; 
            $res_msg = 'Project data has been imported successfully.'; 
        } else { 
            $res_status = 'danger'; 
            $res_msg = 'Something went wrong, please try again.'; 
        } 
    } else { 
        $res_status = 'danger'; 
        $res_msg = 'Please select a valid CSV file.'; 
    } 
    
    // Store status in SESSION 
    $_SESSION['response'] = array( 
        'status' => $res_status, 
        'msg' => $res_msg 
    ); 
} 

// Redirect to the listing page 
header("Location: index.php"); 
exit(); 

require_once('footer.php');
?>
