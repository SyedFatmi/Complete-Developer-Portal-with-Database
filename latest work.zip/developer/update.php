<?php
    require_once('../include/connection.php');
    require_once('../include/header.php');

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $query = "SELECT * FROM `developer` WHERE id = $id";
        $mysqli_query = mysqli_query($con, $query);
        $dev_result = mysqli_fetch_assoc($mysqli_query);
    }
    
    if (isset($_POST['employee-update'])) {
        $dev_name = $_POST['dev-name'];
        $employee_id = $_POST['emp-id'];
        $user_id = $_POST['id'];
    
        $query = "UPDATE `developer` SET `developer_name`='$dev_name',`employee_id`='$employee_id' WHERE id = $user_id";
        $dev_updated = mysqli_query($con, $query);
        if ($dev_updated) {
			echo "<script>window.location.href = '/developer/index.php';</script>";
            exit();
        }
    }
?>

            <?php 
                require_once('../include/sidebar.php');
            ?>

            <div class="col-md-10">
                <form class="employee-form" method="POST">
                    <h2 class="headings">Update a Developer!</h2>
                    <div class="form-group">
                        <label>Developer Name</label>
                        <input type="text" class="form-control" id="dev-name" name="dev-name" value="<?php echo htmlspecialchars($dev_result['developer_name']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Employee ID</label>
                        <input type="text" class="form-control" id="emp-id" name="emp-id" value="<?php echo htmlspecialchars($dev_result['employee_id']); ?>">
                    </div>
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($dev_result['id']); ?>">
                    <button id="updateDeveloper" type="submit" class="mb-5 btn btn-primary filter-btn" name="employee-update" onclick='confirmupdateDeveloper()'>Update Developer</button>
                </form>
            </div>
        </div>
    </div>

<?php
    require_once('../include/footer.php')
?>
    <script>
        function confirmupdateDeveloper(id) {
            Swal.fire({
                title: 'Update Successfully!',
                text: "Your Developer Updated!",
                icon: 'success',
                showConfirmButton:false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '/index.php?id=' + id;
                }
            })
        }
    </script>