<?php
    require_once('../include/connection.php');
    require_once('../include/header.php');
    require_once('../include/sidebar.php');
?>

            <div class="col-md-10">
                <?php
                    if (isset($_POST['employee-submit'])) {
                        $dev_name = mysqli_real_escape_string($con, $_POST['dev-name']);
                        $employee_id = mysqli_real_escape_string($con, $_POST['emp-id']);
                    
                        $check_dev_query = "SELECT id FROM developer WHERE developer_name = '$dev_name' LIMIT 1";
                        $dev_result = mysqli_query($con, $check_dev_query);
                    
                        if (mysqli_num_rows($dev_result) > 0) {
                            echo "<p class='alert alert-danger widths'>Developer '$dev_name' already exists.</p>";
                        } else {
                            $query = "INSERT INTO `developer`(`developer_name`, `employee_id`) VALUES ('$dev_name','$employee_id')";
                            $insert = mysqli_query($con, $query);
                    
                            if($insert){
                                echo "<script>window.location.href = 'index.php';</script>";
                            } else {
                                echo "<p class='alert alert-danger width'>Failed to add developer. Please try again.</p>";
                            }
                        }
                    }
                ?>
                <form class="employee-form" method="POST">
                    <h2 class="headings">Add a Developer!</h2>
                    <div class="form-group dev-names">
                        <label>Developer Name</label>
                        <input type="text" class="form-control" id="dev-name" name="dev-name" placeholder="Developer Name" required>
                    </div>
                    <div class="form-group dev-ids">
                        <label>Employee ID</label>
                        <input type="text" class="form-control" id="emp-id" name="emp-id" placeholder="Employee ID" required>
                    </div>
                    <button type="submit" class="devs-btn btn btn-primary" name="employee-submit">Add Developer</button>
                </form>
                        
                <h2 class="filter-heading">Developer Details!</h2>
                        
                <?php
        
                    $limit = 10;
                    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                    $start = ($page - 1) * $limit;
                    
                    $filter_dev_name = isset($_GET['filter_dev_name']) ? mysqli_real_escape_string($con, $_GET['filter_dev_name']) : '';
                    $filter_emp_id = isset($_GET['filter_emp_id']) ? mysqli_real_escape_string($con, $_GET['filter_emp_id']) : '';
                    
                    $where_clause = "WHERE 1=1";
                    
                    if (!empty($filter_dev_name)) {
                        $where_clause .= " AND developer_name LIKE '%$filter_dev_name%'";
                    }
                    
                    if (!empty($filter_emp_id)) {
                        $where_clause .= " AND employee_id LIKE '%$filter_emp_id%'";
                    }
                    
                    $result = mysqli_query($con, "SELECT COUNT(*) AS total FROM developer $where_clause");
                    $row = mysqli_fetch_assoc($result);
                    $total_records = $row['total'];
                    $total_pages = ceil($total_records / $limit);
                    
                    $start_record = $start + 1;
                    $end_record = min($start + $limit, $total_records);
                    
                    $query = "SELECT * FROM developer $where_clause ORDER BY id DESC LIMIT $start, $limit";
                    $query_run = mysqli_query($con, $query);
                
                ?>
                        
                <table class="table">
                    <thead>
                        <tr>
                            <th>Serial No.</th>
                            <th>Developer Name</th>
                            <th>Employee ID</th>
                            <th class="actions">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($query_run) > 0) {
                            $serial_number = $start + 1; 
                            while ($user_row = mysqli_fetch_assoc($query_run)) {
                                echo "<tr>
                                        <td class='my-tds'>" . $serial_number . "</td>
                                        <td>" . htmlspecialchars($user_row['developer_name']) . "</td>
                                        <td>" . htmlspecialchars($user_row['employee_id']) . "</td>
                                        <td class='actions-btn'>
                                            <a href='update.php?id=" . $user_row['id'] . "' class='edit btn btn-md total-btn'>Update</a>
                                            <a href='delete.php?id=" . $user_row['id'] . "' onclick='confirmdevDelete(" . $user_row['id'] . ")' class='total-btn btn btn-md delete-btn'>Delete</a>
                                        </td>
                                      </tr>";
                                $serial_number++; 
                            }
                        } else {
                            echo "<tr><td colspan='4'>No Developer Records Found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-md-6 project-number">
                        <p class="text-muted">Developers <?php echo $start_record; ?> to <?php echo $end_record; ?> out of <?php echo $total_records; ?> total Developers.</p>
                    </div>
                    <div class="col-md-6 pagination">
                        <nav aria-label="Page navigation example" class="full-pagination">
                            <ul class="pagination">
                                <?php
                                $filter_params = "&filter_dev_name=" . urlencode($filter_dev_name) . "&filter_emp_id=" . urlencode($filter_emp_id);
                
                                if ($page > 1) {
                                    echo '<li class="page-item"><a class="page-link" href="?page=' . ($page - 1) . $filter_params . '">Previous</a></li>';
                                }
                
                                for ($i = 1; $i <= $total_pages; $i++) {
                                    echo '<li class="page-item"><a class="page-link" href="?page=' . $i . $filter_params . '">' . $i . '</a></li>';
                                }
                
                                if ($page < $total_pages) {
                                    echo '<li class="page-item"><a class="page-link" href="?page=' . ($page + 1) . $filter_params . '">Next</a></li>';
                                }
                                ?>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php
    require_once('../include/footer.php');
?>
    <script>
        function confirmdevDelete(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert Developer Details!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'delete.php?id=' + id;
                }
            })
        }
        function confirmaddDeveloper(id) {
            Swal.fire({
                title: 'Added Successfully!',
                text: "Your Developer Added!",
                icon: 'success',
                showConfirmButton:false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'index.php?id=' + id;
                }
            })
        }
    </script>